# Install Instructions 
1. Install node: https://nodejs.org/en
2. Open command prompt in root folder and run "npm install"
3. Open data/config.json and edit to suit your needs.
	- OBS Websocket password
	- Twitch Bot token and details
	- Dicord Bot token and details
4. Setup commands in config.json