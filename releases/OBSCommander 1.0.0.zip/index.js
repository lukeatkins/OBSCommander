const OBSCommander = require("./OBSCommander.js");

var app = new OBSCommander();