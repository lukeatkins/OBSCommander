const OBSWebSocket = require('obs-websocket-js').default;
const tmi = require('tmi.js');
const fs = require('fs');
const Discord = require('discord.js');
const async = require('async');
const { DateTime } = require("luxon");


const config = require("./data/config.json");

class OBSCommander {

	constructor() {
		this.lastScreenshotUser = "";
		this.start();
	}

	start() {
		async.waterfall([
			next => { // OBS
				this.obs = new OBSWebSocket();
				this.connectToOBS(err => {
					if (err) {
						next({Message: "OBS Connect Error", Error: err});
						return;
					}
					next();
				});
			},
			next => {
				this.twitchClient = new tmi.Client(config.Twitch);
				this.connectToTwitch(err => {
					if (err) {
						this.obs.disconnect();
						next({Message: "Twitch Connect Error", Error: err});
						return;
					}
					next();
				});
			},
			next => {
				if (!config.Discord.Enabled) next();
				this.connectToDiscord(err => {
					if (err) {
						this.obs.disconnect();
						this.twitchClient.disconnect();
						next({Message: "Discord Connect Error", Error: err});
						return;
					}
					next();
				});
			}
		], (err) => {
			if (err) {
				return console.log("Failed to Start: ", err.Message, err.Error.message);
			}
			this.twitchClient.on('message', this.onTwitchMessage.bind(this));
			this.twitchClient.on("disconnected", (reason) => {
				console.log("Disconnected from Twitch: ", reason);
				this.connectToTwitch(err => {
					if (err) console.log("Failed to reconnect to Twitch.", err);
				});
			});
			this.obs.on("ConnectionClosed", err => {
				console.log("Disconnected from OBS: ", err);
				this.connectToOBS(err => {
					if (err) console.log("Failed to reconnect to OBS.", err);
				});
			});
		})
	}

	connectToTwitch(callback) {
		this.twitchClient.connect()
		.then(() => {
			console.log(`Connected to Twitch chat as ${config.Twitch.identity.username}`);
			callback();
		})
		.catch(err => {
			console.error(`Failed to connect to Twitch chat: ${err}`);
			callback(err);
		});
	}

	connectToOBS(callback) {
		this.obs.connect(config.OBS.address, config.OBS.password)
		.then(() => {
			console.log(`Connected to OBS`);
			callback();
		})
		.catch(err => {
			console.error(`Failed to connect to OBS: ${err}`);
			callback(err);
		});
	}

	connectToDiscord(callback) {
		this.discord = new Discord.Client({ intents: [Discord.GatewayIntentBits.Guilds, Discord.GatewayIntentBits.GuildMessages] });				
		this.discord.on("ready", () => {
			console.log("Connected to Discord");
			this.startDiscordTasks();
			callback();
		});
		this.discord.login(config.Discord.Bot_Token)
		.catch(err => {
			callback(err);
		});
	}
		
		
		


	onTwitchMessage(channel, tags, message, self) {
		// Ignore messages from the bot itself
		if (self) return;
	  
		// Parse the command and arguments
		const [cmd, ...args] = message.trim().split(/\s+/);
	  
		// Handle the command
		var command = config.Commands.find(e => e.Command == cmd.toLowerCase());
		if (command) {
			this.executeCommand(command, args, channel, tags, message);
		}	  
	}

	executeCommand(command, args, channel, tags, message) {
		var valid = command.Permissions.every(perm => {
			if (tags.badges?.broadcaster == 1) return true;
			switch(perm) {
				case "mod":
					return tags.mod;
				case "sub":
					return tags.subscriber;
			}
		});
		if (!valid) return console.log(`User ${tags["display-name"] ?? tags.username} tried to run command ${command.Command}, but does not have permission`);
		
		console.log(`User ${tags["display-name"] ?? tags.username} running command ${command.Command}`);
		
		if (command.Command == "!screenshot") this.lastScreenshotUser = tags["display-name"] ?? tags.username;
		
		this.obs.call(command.Action.Request, command.Action.RequestData)
		.then(res => {
			console.log("OBS Response: ", res ?? "[empty]");
			if (!command.Action.Response) return;
			var message = command.Action.Response;
			var matches = message.match(/{([^}]+)}/g);
			if (matches) matches.forEach(match => {
				var cmd = "res." + match.substr(1, match.length-2);
				var val = eval(cmd);
				message = message.replace(match, val);
			});
			this.twitchClient.say(channel, message);

		})
		.catch(err => {
			console.log(`Error executing command ${command.Command}`, err);
		});
	}

	startDiscordTasks() {
		this.watchScreenshotFolder();
	}

	watchScreenshotFolder() {
		var folder = config.Discord.Screenshot_Folder;
		try {
			if (!fs.existsSync(folder)) {
				fs.mkdirSync(folder, { recursive: true });
			}
		} catch (err) {
			return console.log("Failed to setup screenshot folder: ", err);	
		}
		if (this.screenshotWatcher) {
			this.screenshotWatcher.close();
		}
		this.screenshotWatcher = fs.watch(folder, { recursive: false }, (eventType, filename) => {
			if (eventType === 'rename' && filename.endsWith('.png')) {
				var filepath = `${config.Discord.Screenshot_Folder}/${filename}`;
				this.watchScreenshot(filepath);
			}
		});
		
	}

	watchScreenshot(filepath, previousSize) {
		fs.stat(filepath, (err, stats) => {
			if (err) return console.log("Failed to get screenshot file stats", err);
			var currentSize = stats.size;
			if (currentSize == 0 || previousSize != currentSize) {
				setTimeout(() => {
					this.watchScreenshot(filepath, currentSize);
				}, 1000);
			} else {
				this.uploadScreenshot(filepath);
			}
		});
	}

	uploadScreenshot(filepath) {
		const attachment = new Discord.AttachmentBuilder(filepath);
		var channel = this.discord.channels.cache.get(config.Discord.Screenshot_Channel);
		var message = `Screenshot taken ${DateTime.now().toFormat(config.Discord.Screenshot_Timestamp)}${this.lastScreenshotUser == "" ? "" : " by " + this.lastScreenshotUser}`;
		// channel.send(message);
		channel.send({ content: message, files: [attachment] });
		var twitchMessage = `Screenshot taken ${this.lastScreenshotUser == "" ? "" : " by " + this.lastScreenshotUser} saved to Discord ${config.Discord.Invite_Link}`;
		this.twitchClient.say(config.Twitch.channels[0], twitchMessage);
	}
}

module.exports = OBSCommander;